package controllers

type JsonResponse struct {
    Response interface{} `json:"response"`
}
