package mysql

import _ "github.com/go-sql-driver/mysql"
