#!/bin/sh
SCRIPTPATH=$(cd "$(dirname "$0")"; pwd)
"$SCRIPTPATH/SemiRevel" -importPath SemiRevel -srcPath "$SCRIPTPATH/src" -runMode dev
